# Image Format Comparison: Lyon Mural

These six files represent the same photograph of the Fresque des Lyonnais
in Lyon, France, saved using different image formats and compression
settings. All have the same pixel dimensions.

## Files

- `01_full_lossless.png` — PNG
- `02_full_lossless.tif` — TIFF
- `04_jpeg_q90.jpg` — JPEG
- `04_jpeg_q50.jpg` — JPEG
- `04_jpeg_q10.jpg` — JPEG
- `10_jpeg2000_lossless.jp2` — JPEG 2000

## Comparison Activity

1. Compare the file sizes. What differences do you notice?
2. Open each image and zoom in on the same area. Can you identify
   differences in image quality?
3. Can you open all six files using your usual image viewer?
4. Which file(s) would you choose for:
   - A preservation master?
   - A web access image?
   Explain your choices.

Be prepared to share your observations with the class.